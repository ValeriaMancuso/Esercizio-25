abstract class Utente {
    codRedd: number;
    redditoAnnuoLordo: number;
    tasseInps: number;
    tasseIrpef: number;
    constructor(_codRedd: number,_redditoAnnuoLordo: number,_tasseInps: number,_tasseIrpef: number) {
        this.codRedd = _codRedd;
        this.redditoAnnuoLordo = _redditoAnnuoLordo;
        this.tasseInps = _tasseInps;
        this.tasseIrpef = _tasseIrpef;
    }
    getUtileTasse(): number {
        return (this.redditoAnnuoLordo * this.codRedd) / 100;
    }
    getTasseInps(): number {
        return (this.getUtileTasse() * this.tasseInps) / 100;
    }
    getTasseIrpef(): number {
        return (this.getUtileTasse() * this.tasseIrpef) / 100;
    }
    getRedditoAnnuoNetto(): number {
        return this.redditoAnnuoLordo - (this.getTasseInps() + this.getTasseIrpef());
    }
}

class Professionista extends Utente {
    constructor(_redditoAnnuoLordo: number) {
        super(78, _redditoAnnuoLordo, 25.72, 5)
    }
}

class Artigiano extends Utente {
    constructor(_redditoAnnuoLordo: number) {
        super(67, _redditoAnnuoLordo, 35, 15)
    }
}

class Commerciante extends Utente {
    constructor(_redditoAnnuoLordo: number) {
        super(40, _redditoAnnuoLordo, 35, 15) 
    }
}

console.log('----PROFESSIONISTA----');
let p1 = new Professionista(45000);
console.log('Reddito annuo lordo: ',p1.redditoAnnuoLordo);
console.log('Utile tasse: ', p1.getUtileTasse());
console.log('Utile tasse Inps: ',p1.getTasseInps());
console.log('Utile tasse Irpef: ',p1.getTasseIrpef());
console.log('Reddito annuo netto: ',p1.getRedditoAnnuoNetto());

console.log('----ARTIGIANO----');
let p2 = new Artigiano(30000);
console.log('Reddito annuo lordo: ',p2.redditoAnnuoLordo);
console.log('Utile tasse: ', p2.getUtileTasse());
console.log('Utile tasse Inps: ',p2.getTasseInps());
console.log('Utile tasse Irpef: ',p2.getTasseIrpef());
console.log('Reddito annuo netto: ',p2.getRedditoAnnuoNetto());

console.log('----COMMERCIANTE----');
let p3 = new Commerciante(25000);
console.log('Reddito annuo lordo: ',p3.redditoAnnuoLordo);
console.log('Utile tasse: ',p3.getUtileTasse());
console.log('Utile tasse Inps: ',p3.getTasseInps());
console.log('Utile tasse Irpef: ',p3.getTasseIrpef());
console.log('Reddito annuo netto: ',p3.getRedditoAnnuoNetto());