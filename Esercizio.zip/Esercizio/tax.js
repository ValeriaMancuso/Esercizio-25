var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Utente = /** @class */ (function () {
    function Utente(_codRedd, _redditoAnnuoLordo, _tasseInps, _tasseIrpef) {
        this.codRedd = _codRedd;
        this.redditoAnnuoLordo = _redditoAnnuoLordo;
        this.tasseInps = _tasseInps;
        this.tasseIrpef = _tasseIrpef;
    }
    Utente.prototype.getUtileTasse = function () {
        return (this.redditoAnnuoLordo * this.codRedd) / 100;
    };
    Utente.prototype.getTasseInps = function () {
        return (this.getUtileTasse() * this.tasseInps) / 100;
    };
    Utente.prototype.getTasseIrpef = function () {
        return (this.getUtileTasse() * this.tasseIrpef) / 100;
    };
    Utente.prototype.getRedditoAnnuoNetto = function () {
        return this.redditoAnnuoLordo - (this.getTasseInps() + this.getTasseIrpef());
    };
    return Utente;
}());
var Professionista = /** @class */ (function (_super) {
    __extends(Professionista, _super);
    function Professionista(_redditoAnnuoLordo) {
        return _super.call(this, 78, _redditoAnnuoLordo, 25.72, 5) || this;
    }
    return Professionista;
}(Utente));
var Artigiano = /** @class */ (function (_super) {
    __extends(Artigiano, _super);
    function Artigiano(_redditoAnnuoLordo) {
        return _super.call(this, 67, _redditoAnnuoLordo, 35, 15) || this;
    }
    return Artigiano;
}(Utente));
var Commerciante = /** @class */ (function (_super) {
    __extends(Commerciante, _super);
    function Commerciante(_redditoAnnuoLordo) {
        return _super.call(this, 40, _redditoAnnuoLordo, 35, 15) || this;
    }
    return Commerciante;
}(Utente));
console.log('----PROFESSIONISTA----');
var p1 = new Professionista(45000);
console.log('Reddito annuo lordo: ', p1.redditoAnnuoLordo);
console.log('Utile tasse: ', p1.getUtileTasse());
console.log('Utile tasse Inps: ', p1.getTasseInps());
console.log('Utile tasse Irpef: ', p1.getTasseIrpef());
console.log('Reddito annuo netto: ', p1.getRedditoAnnuoNetto());
console.log('----ARTIGIANO----');
var p2 = new Artigiano(30000);
console.log('Reddito annuo lordo: ', p2.redditoAnnuoLordo);
console.log('Utile tasse: ', p2.getUtileTasse());
console.log('Utile tasse Inps: ', p2.getTasseInps());
console.log('Utile tasse Irpef: ', p2.getTasseIrpef());
console.log('Reddito annuo netto: ', p2.getRedditoAnnuoNetto());
console.log('----COMMERCIANTE----');
var p3 = new Commerciante(25000);
console.log('Reddito annuo lordo: ', p3.redditoAnnuoLordo);
console.log('Utile tasse: ', p3.getUtileTasse());
console.log('Utile tasse Inps: ', p3.getTasseInps());
console.log('Utile tasse Irpef: ', p3.getTasseIrpef());
console.log('Reddito annuo netto: ', p3.getRedditoAnnuoNetto());
